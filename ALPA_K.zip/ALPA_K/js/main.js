/* ALPA-K Software — interacciones del sitio */
(() => {
  'use strict';

  const WHATSAPP = '51945550393';
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Cabecera al hacer scroll ---------- */
  const header = document.querySelector('.site-header');
  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  /* ---------- Menú móvil ---------- */
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('nav');

  const setMenu = (open) => {
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
    document.body.classList.toggle('nav-open', open);
  };

  toggle.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  nav.addEventListener('click', (e) => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && document.body.classList.contains('nav-open')) {
      setMenu(false);
      toggle.focus();
    }
  });
  window.matchMedia('(min-width: 960px)').addEventListener('change', (e) => { if (e.matches) setMenu(false); });

  /* ---------- Enlace activo según la sección visible ---------- */
  const navLinks = [...document.querySelectorAll('.nav-list a')];
  if ('IntersectionObserver' in window) {
    const spy = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const id = `#${entry.target.id}`;
        navLinks.forEach((a) => a.classList.toggle('is-active', a.getAttribute('href') === id));
      });
    }, { rootMargin: '-45% 0px -50% 0px' });

    document.querySelectorAll('main section[id]').forEach((s) => spy.observe(s));
  }

  /* ---------- Aparición al hacer scroll ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  if (reduceMotion || !('IntersectionObserver' in window)) {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

    revealEls.forEach((el) => {
      const siblings = [...el.parentElement.children].filter((c) => c.classList.contains('reveal'));
      el.style.setProperty('--d', `${Math.min(siblings.indexOf(el), 5) * 80}ms`);
      io.observe(el);
    });
  }

  /* ---------- Terminal animada del hero ---------- */
  const term = document.querySelector('#terminal code');
  if (term && !reduceMotion) {
    const PROMPT = '<span class="t-prompt">&gt;</span> ';
    const lines = term.innerHTML.split('\n');
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const cursor = document.createElement('span');
    cursor.className = 't-cursor';

    const newRow = () => {
      const row = document.createElement('span');
      term.appendChild(row);
      return row;
    };

    const play = async () => {
      for (;;) {
        term.innerHTML = '';
        for (const line of lines) {
          const row = newRow();
          if (line.startsWith(PROMPT)) {
            const tmp = document.createElement('span');
            tmp.innerHTML = line.slice(PROMPT.length);
            const typed = document.createElement('span');
            row.innerHTML = PROMPT;
            row.append(typed, cursor);
            await sleep(450);
            for (const ch of tmp.textContent) {
              typed.textContent += ch;
              await sleep(26 + Math.random() * 44);
            }
            await sleep(380);
          } else {
            row.innerHTML = line;
            row.append(cursor);
            await sleep(300);
          }
          row.after(document.createTextNode('\n'));
        }
        const last = newRow();
        last.innerHTML = PROMPT;
        last.append(cursor);
        await sleep(5000);
      }
    };
    play();
  }

  /* ---------- Formulario → WhatsApp ---------- */
  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');
  const required = [
    { input: form.elements.nombre, error: document.getElementById('e-nombre') },
    { input: form.elements.mensaje, error: document.getElementById('e-mensaje') },
  ];

  required.forEach(({ input, error }) => {
    input.addEventListener('input', () => {
      if (input.value.trim()) {
        input.removeAttribute('aria-invalid');
        error.hidden = true;
      }
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    status.textContent = '';

    let firstInvalid = null;
    required.forEach(({ input, error }) => {
      const ok = input.value.trim().length > 0;
      input.setAttribute('aria-invalid', String(!ok));
      error.hidden = ok;
      if (!ok && !firstInvalid) firstInvalid = input;
    });
    if (firstInvalid) {
      firstInvalid.focus();
      return;
    }

    const nombre = form.elements.nombre.value.trim();
    const empresa = form.elements.empresa.value.trim();
    const servicio = form.elements.servicio.value;
    const mensaje = form.elements.mensaje.value.trim();

    const text = [
      `Hola ALPA-K 👋, soy ${nombre}${empresa ? ` de ${empresa}` : ''}.`,
      `Me interesa: ${servicio}.`,
      '',
      mensaje,
    ].join('\n');

    const url = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`;
    const win = window.open(url, '_blank');
    if (win) {
      win.opener = null;
    } else {
      window.location.href = url;
    }
    status.textContent = '¡Listo! Se abrió WhatsApp con tu mensaje. Solo presiona enviar.';
  });

  /* ---------- Año del pie de página ---------- */
  document.getElementById('year').textContent = new Date().getFullYear();
})();
