# ALPA-K Software — Sitio web

Sitio estático (HTML + CSS + JS, sin dependencias). Funciona en cualquier hosting.

## Estructura

```
index.html              Página principal (todo el contenido)
css/styles.css          Estilos (colores de marca en :root, al inicio)
js/main.js              Menú móvil, terminal animada, formulario → WhatsApp
assets/logo/            Logo vectorizado (SVG)
  alpa-k-logo.svg         Con fondo azul marino (como el original)
  alpa-k-logo-blanco.svg  Fondo transparente, para fondos oscuros
  alpa-k-logo-oscuro.svg  Fondo transparente, para fondos claros (documentos, papelería)
  alpa-k-icono.svg        Ícono ">_" (favicon, foto de perfil)
```

## Verlo en tu computadora

Abre `index.html` con doble clic, o levanta un servidor local:

```
python -m http.server 5173
```

y entra a http://localhost:5173

## Publicarlo

Sube **todo el contenido de esta carpeta** (excepto `.claude/` y `logo.jpg`) a la raíz del hosting.
Opciones gratuitas: Netlify (arrastrar la carpeta), GitHub Pages o Cloudflare Pages.

## Cambios frecuentes

- **Número de WhatsApp:** buscar `51945550393` en `index.html` y `js/main.js`.
- **Mensaje predeterminado:** está codificado en los enlaces `wa.me/...?text=` de `index.html`.
- **Capturas reales de Ascrigar:** ver el comentario en la sección `#proyectos` de `index.html`.
- **Al tener dominio:** agregar `og:url` y `og:image` (con URL absoluta) en el `<head>`.
